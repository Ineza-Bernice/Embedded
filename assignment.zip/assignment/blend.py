import cv2  # Import OpenCV library

# Read the image
image = cv2.imread('assignment_001_given.jpg')


# Text settings
text = 'RAH972U'
org = (900, 130)  # Top-left corner of the text
font = cv2.FONT_HERSHEY_SIMPLEX
font_scale = 2
text_color = (0, 0, 0)  # Green
line_thickness = 5

# Get the text size
(text_width, text_height), baseline = cv2.getTextSize(text, font, font_scale, line_thickness)

# Coordinates for the background rectangle
bg_start = (org[0] - 10, org[1] - text_height - 10)  # Add padding
bg_end = (org[0] + text_width + 10, org[1] + baseline)  # Add padding

# Draw the background rectangle (filled)
cv2.rectangle(image, bg_start, bg_end, (0, 0, 0), -1)  # Black background

# Add the text on top of the background rectangle
cv2.putText(image, text, org, font, font_scale, text_color, line_thickness)

# Display the image in a new window named 'Image'
cv2.imshow('Image', image)

# Wait indefinitely until a key is pressed
cv2.waitKey(0)

# Save the final image
cv2.imwrite('cara.jpg', image)

# Close all OpenCV windows to release resources
cv2.destroyAllWindows()
